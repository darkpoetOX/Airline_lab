package com.bnta.airline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
