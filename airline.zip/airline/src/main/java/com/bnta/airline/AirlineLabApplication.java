package com.bnta.airline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineLabApplication.class, args);
	}

}
